package com.fse.usecase.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fse.usecase.model.Users;
import com.fse.usecase.model.userTweets;
import com.fse.usecase.service.LoginServices;
import com.fse.usecase.service.TweetService;

@Controller
@RequestMapping("/login")
public class TweetController {
	
	@Autowired
	private LoginServices loginService;
	
	@Autowired
	private TweetService tweetService;
	@RequestMapping(value="/home", method = RequestMethod.GET)
	@ResponseBody
   public String homepage()
   {
	 Users dummyData=new Users("vamsi","vanama","male",new Date(),"test1.com","vamsi123");
	 int k=loginService.registerUserIntoDB(dummyData);
	 if(k>0)
	   return "welcome vamsi";
	 return "wasted";
   }
	@RequestMapping(value="/alltweets", method = RequestMethod.GET)
	@ResponseBody
	public String allTweets()
	{
		List<userTweets> allTweets=tweetService.getAllTweetsFroomDB();
		System.out.println(allTweets);
	
		return "success";
	}
	
	@RequestMapping(value="/allmytweets", method = RequestMethod.GET)
	@ResponseBody
	public String allmyTweets()
	{
		List<userTweets> allTweets=tweetService.getAllMyTweetsFromDB("vamsi@gmail.com");
		System.out.println(allTweets);
	
		return "success my tweets";
	}
	
	@RequestMapping(value="/updatepassword", method = RequestMethod.GET)
	@ResponseBody
	public String updatePassword()
	{
		int p=loginService.updatePassword("9989105072", "vamsi@gmail.com");
		
		if(p>0)
		return "updated password";
		
		return "Wasted";
	}
	
	@RequestMapping(value="/logincheck", method = RequestMethod.GET)
	@ResponseBody
	public String loginCheck()
	{
		boolean k=loginService.loginCheck("vamsi@gmail.com", "99891050789");
		
		if(k==true)
		return "login success";
		
		return "login failure";
	}
	

}
