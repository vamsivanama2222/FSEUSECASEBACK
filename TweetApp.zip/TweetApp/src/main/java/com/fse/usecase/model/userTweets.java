package com.fse.usecase.model;

public class userTweets {

	private String userName;
	private String userEmail;
	private String tweetMsg;
	public userTweets(String userName, String userEmail, String tweetMsg) {
		super();
		this.userName = userName;
		this.userEmail = userEmail;
		this.tweetMsg = tweetMsg;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getTweetMsg() {
		return tweetMsg;
	}
	public void setTweetMsg(String tweetMsg) {
		this.tweetMsg = tweetMsg;
	}
	public userTweets() {
		super();
		// TODO Auto-generated constructor stub
	}
}
